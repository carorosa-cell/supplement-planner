# 💊 Supplement Planner

Dein intelligenter Einnahmeplan für Nahrungsergänzungsmittel.

## So bringst du die App auf dein Handy

### Schritt 1: GitHub-Konto erstellen
1. Gehe zu **github.com** und erstelle ein kostenloses Konto
2. Klicke auf **"New Repository"** (grüner Button)
3. Nenne es `supplement-planner`
4. Klicke **"Create repository"**

### Schritt 2: Code hochladen
1. Auf deiner neuen Repository-Seite klicke **"uploading an existing file"**
2. Ziehe den gesamten Inhalt dieses Ordners per Drag & Drop hinein
   - Wichtig: Lade die Ordnerstruktur so hoch wie sie ist (public/, src/, package.json)
3. Klicke **"Commit changes"**

### Schritt 3: Mit Vercel verbinden
1. Gehe zu **vercel.com** und klicke **"Sign Up"**
2. Wähle **"Continue with GitHub"** (mit deinem neuen GitHub-Konto)
3. Klicke **"Add New Project"**
4. Wähle dein `supplement-planner` Repository aus
5. Klicke **"Deploy"** – fertig! 🎉

### Schritt 4: Auf dem Handy speichern
1. Vercel gibt dir eine URL (z.B. `supplement-planner-abc.vercel.app`)
2. Öffne diese URL auf deinem Handy in Safari/Chrome
3. **iPhone:** Teilen-Button (↑) → "Zum Home-Bildschirm"
4. **Android:** Drei-Punkte-Menü → "Zum Startbildschirm hinzufügen"

Fertig! Die App liegt jetzt als Icon auf deinem Handy. 📱
